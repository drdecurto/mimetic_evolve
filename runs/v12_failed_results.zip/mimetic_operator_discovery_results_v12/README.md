# Mimetic operator discovery v7 open-program run

Schema: 2.6.0
Started: 2026-08-19T09:44:47.765042+00:00

LIVE Nebius calls were executed. Mock outputs, when present, are harness checks only and are not scientific evidence.

The closed-grid promoted candidates pass their v4 gates. The open-program section additionally
supports exact block-SPD norms, independent closures, repeated controls, and PDE-in-loop evaluation.
All promoted open candidates require exact coupled affine reconstruction, direct Sylvester SPD proof, conservation and moment identities, Q-symmetry, a real non-positive spectrum,
physical low-mode assignment with no extra low modes, scaled inverse conditioning, two
manufactured-PDE gates, and unseen-mesh transfer.

The bundled novelty library is explicitly partial. Novelty remains unassessed until all relevant
same-topology mimetic/SBP coefficient families are loaded and canonically compared.
